/*
For general Scribus (>=1.3.2) copyright and licensing information please refer
to the COPYING file provided with the program. Following this notice may exist
a copyright and/or license notice that predates the release of Scribus 1.3.2
for which a new license (GPL+exception) is in place.
*/
#ifndef OPENDTPIMPL_H
#define OPENDTPIMPL_H

#include <QObject>
#include <iostream>
#include <fstream>


#define PORT_NUMBER 8080

using namespace std;

class QString;
class ScribusDoc;

class OpenDtpImpl : public QObject
{
  int s_fd;
  ofstream log;
  std::string debug;
	Q_OBJECT
	public:
		OpenDtpImpl();
		~OpenDtpImpl();
		bool run(const QString & target, ScribusDoc* doc=0);
    bool create_socket();
    bool read_socket();
    void write_to_socket(int fd, const char *str);
};

#endif
