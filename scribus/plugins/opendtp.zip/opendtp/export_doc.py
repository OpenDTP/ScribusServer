#!/usr/bin/env python
# -*- coding: utf-8 -*-

from scribus import *

scribus.messageBox("Finished", "This is the End!",icon=0,button1=1)