/*
For general Scribus (>=1.3.2) copyright and licensing information please refer
to the COPYING file provided with the program. Following this notice may exist
a copyright and/or license notice that predates the release of Scribus 1.3.2
for which a new license (GPL+exception) is in place.
*/
#include "opendtpimpl.h"
#include "scribusdoc.h"

#include <QString>
#include <QMessageBox>

#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>

// Initialize members here, if any
OpenDtpImpl::OpenDtpImpl() : QObject(0)
{
  log.open("opendtp.log", ios::in);
}

OpenDtpImpl::~OpenDtpImpl()
{
  log.close();
}

bool OpenDtpImpl::create_socket()
{
  struct sockaddr_in serv_addr;

  this->debug += "Trying to create the socket\n";
  this->s_fd = socket(AF_INET, SOCK_STREAM, 0);
  if (this->s_fd < 0)
  {
    this->debug += "Error creating the socket\n";
    perror("Error creating the socket");
    return false;
  }
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(PORT_NUMBER);
  if (bind(this->s_fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
  {
    this->debug += "Error binding the socket\n";
    perror("Error binding the socket");
    return false;
  }
  listen(this->s_fd, 42);
  this->debug += "Correctly created the socket\n";
  return true;
}

void OpenDtpImpl::write_to_socket(int fd, const char *str)
{
  write(fd, str, strlen(str));
}

bool OpenDtpImpl::read_socket()
{
  socklen_t           clilen;
  int                 newsockfd;
  int                 n = 0;
  struct sockaddr     cli_addr;
  char                buffer[256];

  clilen = sizeof(cli_addr);
  newsockfd = accept(this->s_fd, &cli_addr, &clilen);
  bzero(buffer, 256);
  this->write_to_socket(newsockfd, "{test : \"valid\"}\n");
  while (1)
  {
    n = recv(newsockfd, buffer, 255, 0);
    if (n < 0) {
      this->debug += "ERROR reading from socket\n";
      return false;
    }
    if (n > 0)
    {
      system("python /tmp/opendtp/export_doc.py > /tmp/opendtp.log 2> /tmp/opendtp.log");
      this->write_to_socket(newsockfd, "{test : \"valid\"}\n");
      this->debug += "RECEIVED : ";
      this->debug += buffer;
    }
    if (n == 0) {
      close(newsockfd);
      return true;
    }
  }
  close(newsockfd);
  return true;
}

bool OpenDtpImpl::run(const QString & target, ScribusDoc* doc)
{
  if (this->create_socket())
    this->read_socket();
  if (target != NULL && doc != NULL) {
	  QMessageBox::information(
			(QWidget*)doc->scMW(),
			tr("Scribus - OpenDTP Plugin"),
			tr(this->debug.c_str()),
			QMessageBox::Ok|QMessageBox::Default|QMessageBox::Escape,
			QMessageBox::NoButton);
  }
	return true;
}
